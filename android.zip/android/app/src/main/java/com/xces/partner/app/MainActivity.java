package com.xces.partner.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
